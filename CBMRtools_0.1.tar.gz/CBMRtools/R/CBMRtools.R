#' CBMRtools
#' 
#' A package for accessing general-use R scripts developed by montilab members
#' @name CBMRtools
#' @docType package
NULL
